-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Feb 06, 2022 at 07:11 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bp_test1_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_countries`
--

DROP TABLE IF EXISTS `tbl_countries`;
CREATE TABLE `tbl_countries` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `iso2` varchar(2) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ISO 3166-1 alpha-2 codes are two-letter country codes defined in ISO 3166-1',
  `iso3` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'ISO 3166-1 alpha-3 codes are three-letter country codes defined in ISO 3166-1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_countries`
--

REPLACE INTO `tbl_countries` (`id`, `name`, `iso2`, `iso3`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Austria', 'AT', 'AUT', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(2, 'France', 'FR', 'FRA', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(3, 'Germany', 'DE', 'DEU', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(4, 'Spain', 'ES', 'ESP', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(5, 'Russian Federation', 'RU', 'RUS', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(6, 'China', 'CN', 'CHN', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_failed_jobs`
--

DROP TABLE IF EXISTS `tbl_failed_jobs`;
CREATE TABLE `tbl_failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_migrations`
--

DROP TABLE IF EXISTS `tbl_migrations`;
CREATE TABLE `tbl_migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_migrations`
--

REPLACE INTO `tbl_migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_02_06_175741_create_countries_table', 1),
(6, '2022_02_06_180630_create_user_details_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_password_resets`
--

DROP TABLE IF EXISTS `tbl_password_resets`;
CREATE TABLE `tbl_password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_personal_access_tokens`
--

DROP TABLE IF EXISTS `tbl_personal_access_tokens`;
CREATE TABLE `tbl_personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

DROP TABLE IF EXISTS `tbl_users`;
CREATE TABLE `tbl_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Typically less than 30 character',
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Hash algorithm',
  `active` tinyint(1) NOT NULL DEFAULT 1 COMMENT 'true means active, false mean inactive',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_users`
--

REPLACE INTO `tbl_users` (`id`, `name`, `email`, `email_verified_at`, `password`, `active`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'UCXnrCVtgw', 'alex@tempmail.com', '2022-02-06 15:33:03', '$2y$04$buvpetqN49/EItDs5KOj5.ejI6g5Xwp2R79lbrAWOhR.UHxILsuvG', 1, 'DOnPbsXChm', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(2, 'Qiky604DwI', 'maria@tempmail.com', '2022-02-06 15:33:03', '$2y$04$O36NC9pCqr1Zk/1mEGnZ3eXddCO5LpgEpuRVvnoBJsj/Zk7jgghVu', 1, 'tRiyEvqKgx', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(3, 'Igd9Jr1jrH', 'john@tempmail.com', '2022-02-06 15:33:03', '$2y$04$gD1fk.Uw88kyPjjx/91NNO8zURyJolZ2zd/dbauShGj8NRA9cZL7.', 1, 'LBA1CTTaXu', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(4, 'vVmb5aWuGT', 'dominik@test.com', '2022-02-06 15:33:03', '$2y$04$oSMibXHT6DyVrFHyTd1lQOUIq9RND/JEyVgOMksIxfCbQqJO9yECi', 0, 'Rliby67H5p', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(5, 'FIcN1Ptz5S', 'andreas@yahoo.de', '2022-02-06 15:33:03', '$2y$04$D9Cj4jq7zD79YpNCyGt.POOddE38bNxD9KAg1AGx5MJHyAZkscaqu', 0, 'LYwOGooczo', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(6, 'Pt3ubGIuNK', 'taaaaaaa@test.com', '2022-02-06 15:33:03', '$2y$04$7OCdBYR2ykODM8Xx5b2ssemFE2bjK7Dw1cBEFD9LIXEaEWJmFOia2', 1, 'uTA5HRlrRC', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL),
(7, 'RPQow2IQQa', 'rerere@test_mail.com', '2022-02-06 15:33:03', '$2y$04$mQ0.8Prv/mIsPMuC4Pz6OOZqvybjJ4HCul6srKJ/sfkKwug7kmqze', 1, 'aNW526scAI', '2022-02-06 15:33:03', '2022-02-06 15:33:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_details`
--

DROP TABLE IF EXISTS `tbl_user_details`;
CREATE TABLE `tbl_user_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `citizenship_country_id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Typically consist of 11 digits',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_user_details`
--

REPLACE INTO `tbl_user_details` (`id`, `user_id`, `citizenship_country_id`, `first_name`, `last_name`, `phone_number`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, 'Alex', 'Petro', '0043664111111', NULL, NULL, NULL),
(2, 4, 1, 'Dominik', 'Allan', '00436644444444', NULL, NULL, NULL),
(3, 5, 3, 'Andreas', 'Snow', '004366455555555', NULL, NULL, NULL),
(4, 7, 5, 'Igor', 'Snow', '0043664777777', NULL, NULL, NULL),
(5, 6, 1, 'Max', 'Mastermind', '00436646666666', NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_countries`
--
ALTER TABLE `tbl_countries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_failed_jobs`
--
ALTER TABLE `tbl_failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `tbl_migrations`
--
ALTER TABLE `tbl_migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_password_resets`
--
ALTER TABLE `tbl_password_resets`
  ADD KEY `tbl_password_resets_email_index` (`email`);

--
-- Indexes for table `tbl_personal_access_tokens`
--
ALTER TABLE `tbl_personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_personal_access_tokens_token_unique` (`token`),
  ADD KEY `tbl_personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `tbl_users_email_unique` (`email`),
  ADD KEY `tbl_users_active_index` (`active`);

--
-- Indexes for table `tbl_user_details`
--
ALTER TABLE `tbl_user_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_user_details_user_id_foreign` (`user_id`),
  ADD KEY `tbl_user_details_citizenship_country_id_foreign` (`citizenship_country_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_countries`
--
ALTER TABLE `tbl_countries`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_failed_jobs`
--
ALTER TABLE `tbl_failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_migrations`
--
ALTER TABLE `tbl_migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_personal_access_tokens`
--
ALTER TABLE `tbl_personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_user_details`
--
ALTER TABLE `tbl_user_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_user_details`
--
ALTER TABLE `tbl_user_details`
  ADD CONSTRAINT `tbl_user_details_citizenship_country_id_foreign` FOREIGN KEY (`citizenship_country_id`) REFERENCES `tbl_countries` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `tbl_user_details_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `tbl_users` (`id`) ON DELETE CASCADE;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
